# Orientação dos modelos Word legados

## Escopo e arquivos

Este diretório é um acervo histórico binário. Não altere DOCX, PDF, XSL ou BAT automaticamente e não o use como fonte do build LaTeX.

## Restrições

Não escreva nem edite conteúdo acadêmico nos DOCX. Quando um estudante usar um modelo, explique recursos do Word, a estrutura esperada e problemas observados para que ele mesmo faça as alterações. Antes de orientar a instalação do XSL/BAT, explique que o script é legado e deve ser inspecionado pelo usuário.

## Validação e conclusão

Não há build automatizado. Para manutenção técnica, valide DOCX como pacotes ZIP, PDFs com `pdfinfo` e preserve os hashes durante movimentações. Conclua somente sem perda de arquivos e com mudanças isoladas do fluxo LaTeX atual.
