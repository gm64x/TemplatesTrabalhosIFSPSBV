# Modelos Word legados

Este diretório preserva os modelos Word históricos que antes estavam compactados em `Arquivo/templates trabalhos ms word.rar`.

- Os seis arquivos DOCX são fontes históricas, em versões com e sem referências gerenciadas.
- `Estilo Bibliográfico Word/` contém o estilo ABNT e seu instalador original.
- Os três PDFs são pré-visualizações históricas; não são saídas do build LaTeX atual.

O RAR e seu ZIP interno foram removidos após verificação de integridade. O ZIP apenas duplicava os DOCX e os dois arquivos do estilo bibliográfico. Estes arquivos não participam do Docker, CI ou releases LaTeX e são mantidos somente para evitar perda do material legado.
